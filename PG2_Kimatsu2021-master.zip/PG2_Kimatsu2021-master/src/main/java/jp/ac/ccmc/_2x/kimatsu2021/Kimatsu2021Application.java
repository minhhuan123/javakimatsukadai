package jp.ac.ccmc._2x.kimatsu2021;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Kimatsu2021Application {

	public static void main(String[] args) {
		SpringApplication.run(Kimatsu2021Application.class, args);
	}

}
