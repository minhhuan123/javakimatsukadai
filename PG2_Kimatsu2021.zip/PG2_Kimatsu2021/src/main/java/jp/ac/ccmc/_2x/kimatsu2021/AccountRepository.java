package jp.ac.ccmc._2x.kimatsu2021;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountRepository extends JpaRepository<Account, Long> {

}