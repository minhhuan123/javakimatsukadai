package jp.ac.ccmc._2x.kimatsu2021;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Kimatsu2021ApplicationTests {

	@Test
	void contextLoads() {
	}

}
